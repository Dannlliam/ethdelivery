import i18n from "i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import { initReactI18next } from "react-i18next";

// Import translation files for all supported languages
import en from "@/utils/translation/en.json"; // English
import de from "@/utils/translation/de.json"; // German
import am from "@/utils/translation/am.json"; // Amharic
import ar from "@/utils/translation/ar.json"; // Arabic
import zh from "@/utils/translation/zh.json"; // Chinese
import es from "@/utils/translation/es.json"; // Spanish

i18n
  .use(LanguageDetector) // Detect user language
  .use(initReactI18next) // Initialize i18next
  .init({
    // Add all translation resources
    resources: {
      en: { translation: en },
      de: { translation: de },
      am: { translation: am },
      ar: { translation: ar },
      zh: { translation: zh },
      es: { translation: es },
    },
    debug: true, // Enable debug mode for development
    fallbackLng: "en", // Default language if translation is missing
    supportedLngs: ["en", "de", "am", "ar", "zh", "es"], // Explicitly list supported languages
    nonExplicitSupportedLngs: true, // Allow non-explicit language codes (e.g., "en-US")
    interpolation: {
      escapeValue: false, // Disable escaping for HTML in translations
    },
    detection: {
      // Order of language detection methods
      order: ["cookie", "localStorage", "navigator", "htmlTag"],
      caches: ["cookie"], // Cache detected language in cookies
    },
  });

export default i18n;
